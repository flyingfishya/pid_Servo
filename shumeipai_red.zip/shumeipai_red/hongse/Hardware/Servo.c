#include "stm32f10x.h"                  // Device header
#include "PWM.h"

void Servo_Init(void)
{
	PWM_Init();
	TIM3_PWM12_Init(20000-1,72-1);
}

void Servo_SetAngle(float Angle)
{
//	PWM_SetCompare2(Angle / 240 * 2500 + 0);
	PWM_SetCompare2(Angle);
}

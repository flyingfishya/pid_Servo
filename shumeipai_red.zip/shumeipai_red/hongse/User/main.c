#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Servo.h"
#include "Key.h"
#include "PWM.h"
#include "timer.h"
//1510 x  //1320
unsigned int center_x=1325,center_y=1425;//x1325 y1425
unsigned int left_x=1475,left_y=1525;
unsigned int top_x=1520,top_y=1090,w,h,now_x=1525,now_y=1240,gettop_x,gettop_y;
int mode = 0;
unsigned char jieshou[10];
unsigned char jieshoujuxing[10];
unsigned char jieshou_flag=0,n;
unsigned char now1_x,now1_y,now2_x,now2_y,now3_x,now3_y,now4_x,now4_y,now5_x,now5_y,now6_x,now6_y,now7_x,now7_y,now8_x,now8_y;
unsigned char red_x,red_y;
int turn_x,turn_y; 
int go_x,go_y;
unsigned int weishu=0,duqu_n=0;
unsigned char rx_buf,zuobiaoshu,rx_flag=1,dianshu=0;
unsigned char jiehshousuoyou[100],zongci=0;
unsigned char chazhi_x=0,chazhi_y=0;
unsigned char zuida_x,zuida_y,zuixiao_x,zuixiao_y;
unsigned int timer_pid= 0,pidgo_flag=0;
float duanshu,bilibili;
unsigned char stop_flag = 0;
unsigned int si_x,si_y,si_num;
unsigned int zhengzhi_x,zhengzhi_y;

uint8_t KeyNum = 0,begin_mode=0;
float Angle_y = 1320;//begin
float Angle_x = 1800;//begin
float px=0.0,py;    
typedef struct{
	float SetPoint;
	float LastError;		//�?'???2?
	float PrevError;		//�?�?'???2?
	float SumError;
	float KP;		
	float KI;		
	float KD;	
}PID;

PID read_x,read_y;
int next_x=0,next_y=0;

void uart2_init(u32 bound)
{
	  GPIO_InitTypeDef GPIO_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    
    /* Enable the USART2 Pins Software Remapping */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_AFIO, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2|RCC_APB2Periph_AFIO, ENABLE); 
    
    /* Configure USART2 Rx (PA.03) as input floating */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;    
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    /* Configure USART2 Tx (PA.02) as alternate function push-pull */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    /* Enable the USART2 Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);    
    
    USART_InitStructure.USART_BaudRate = bound;                
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;     
    USART_InitStructure.USART_Parity = USART_Parity_No;        
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;      
    
    USART_Init(USART2, &USART_InitStructure);
    USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
    /* Enable USART2 */
    USART_Cmd(USART2, ENABLE);
}


void PID_Init_x(PID* sptr)
{

	sptr->LastError = 0;       
	sptr->PrevError = 0;                                              
	sptr->SetPoint =  0;		
	sptr->SumError =  0;		
	sptr->KP=0.4;//0.9
	sptr->KI=0.15;//0.4
	sptr->KD=0;//0.01
}

void PID_Init_y(PID* sptr)
{

	sptr->LastError = 0;       
	sptr->PrevError = 0;                                              
	sptr->SetPoint =  0;		
	sptr->SumError =  0;		
	sptr->KP=0.4;
	sptr->KI=0.15;
	sptr->KD=0;
}

float PID_Contrl(PID* sptr,float NextPoint)
{
	float iError,dError,iIncPid;
	
	iError = sptr->SetPoint - NextPoint;	
	
	sptr->SumError+=iError;
	
	dError=sptr->LastError-sptr->PrevError;
	
	iIncPid =sptr->KP* iError;				
          + sptr->KI * sptr->SumError
    	    + sptr->KD * 	dError;

	sptr->PrevError = sptr->LastError;
	sptr->LastError = iError;	
	
//	if(iIncPid>999)
//		iIncPid=999;   
//	if(iIncPid<0)
//		iIncPid=0;  
	return iIncPid;						
}


void begin(unsigned int center_x,unsigned int center_y)     //???
{
  PWM_SetCompare2(center_y); //y
	PWM_SetCompare3(center_x); //x//fuwei
//	Delay_ms(1000);
////	PWM_SetCompare3(1667);
////	Delay_ms(1000);
////	PWM_SetCompare2(1390);//y
////	PWM_SetCompare3(1620);	//x
////	Delay_ms(1000);//zuoxia
////	
////	PWM_SetCompare2(1190);//y
////	PWM_SetCompare3(1620);	//x
////	Delay_ms(350);
////	PWM_SetCompare2(1190);//y
////	PWM_SetCompare3(1420);	//x
////	Delay_ms(350);
////	PWM_SetCompare2(1390);//y
////	PWM_SetCompare3(1420);	//x
////	Delay_ms(350);
////	PWM_SetCompare2(1390);//y
////	PWM_SetCompare3(1620);	//x
////	Delay_ms(350);
// draw(center_x,center_y,left_x,left_y);
}

void draw(unsigned int center_x,unsigned int center_y,unsigned int left_x,unsigned int left_y)
{
	unsigned int x_turn,y_turn;
	x_turn = 2*(left_x-center_x);
	y_turn = 2*(left_y-center_y);
	PWM_SetCompare3(left_x);//y
	PWM_SetCompare2(left_y);	//x
	Delay_ms(350);
	PWM_SetCompare3(left_x);//y
	PWM_SetCompare2(left_y-y_turn);	//x
	Delay_ms(350);
	PWM_SetCompare3(left_x-x_turn);//y
	PWM_SetCompare2(left_y-y_turn);	//x
	Delay_ms(350);
	PWM_SetCompare2(left_y);//y
	PWM_SetCompare3(left_x-x_turn);	//x
	Delay_ms(350);
	PWM_SetCompare3(left_x);//y
	PWM_SetCompare2(left_y);	//x
	Delay_ms(350);
}

void who_is()
{
	if(now1_x>now2_x)
	{
		zuida_x = now1_x;
		zuixiao_x = now2_x;
	}
	else
	{
		zuida_x = now2_x;
		zuixiao_x = now1_x;
	}
	if(now3_x>zuida_x)
	{
		zuida_x=now3_x;
	}
	else if(now3_x<zuixiao_x)
	{
		zuixiao_x = now3_x;
	}
	if(now4_x>zuida_x)
	{
		zuida_x=now4_x;
	}
	else if(now4_x<zuixiao_x)
	{
		zuixiao_x = now4_x;
	}
	
	
	
	
if(now1_y>now2_y)
	{
		zuida_y = now1_y;
		zuixiao_y = now2_y;
	}
	else
	{
		zuida_y = now2_y;
		zuixiao_y = now1_y;
	}
	if(now3_y>zuida_y)
	{
		zuida_y=now3_y;
	}
	else if(now3_y<zuixiao_y)
	{
		zuixiao_y = now3_y;
	}
	if(now4_y>zuida_y)
	{
		zuida_y=now4_y;
	}
	else if(now4_y<zuixiao_y)
	{
		zuixiao_y = now4_y;
	}
	
	now1_x = zuixiao_x;
	now1_y = zuixiao_y;
	
	now2_x = zuida_x;
	now2_y = zuixiao_y;
	
	now3_x = zuida_x;
	now3_y = zuida_y;
	
	now4_x = zuixiao_x;
	now4_y = zuida_y;
}


void anjian_init()
{
	GPIO_InitTypeDef GPIO_InitStructure;

 	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOC,ENABLE);//ʹ��PORTA,PORTCʱ��

	//GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);//�ر�jtag��ʹ��SWD��������SWDģʽ����
	
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_15;//PA15
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; //���ó���������
 	GPIO_Init(GPIOA, &GPIO_InitStructure);//��ʼ��GPIOA15
//	
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_5;//PC5
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; //���ó���������
 	GPIO_Init(GPIOC, &GPIO_InitStructure);//��ʼ��GPIOC5
// 
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0;//PA0
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD; //PA0���ó����룬Ĭ������	  
	GPIO_Init(GPIOA, &GPIO_InitStructure);//��ʼ��GPIOA.0
	
	
	
}


//void EXTIX_Init(void)
//{  
// 	  EXTI_InitTypeDef EXTI_InitStructure;
// 	  NVIC_InitTypeDef NVIC_InitStructure;

//  	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);//�ⲿ�жϣ���Ҫʹ��AFIOʱ��

//	  anjian_init();//��ʼ��������Ӧioģʽ

//    //GPIOC.5 �ж����Լ��жϳ�ʼ������
//  	GPIO_EXTILineConfig(GPIO_PortSourceGPIOC,GPIO_PinSource5);

//  	EXTI_InitStructure.EXTI_Line=EXTI_Line5;
//  	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;	
//  	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;//�½��ش���
//  	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
//  	EXTI_Init(&EXTI_InitStructure);	 	//����EXTI_InitStruct��ָ���Ĳ�����ʼ������EXTI�Ĵ���

//    //GPIOA.15	  �ж����Լ��жϳ�ʼ������
//  	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA,GPIO_PinSource15);

//  	EXTI_InitStructure.EXTI_Line=EXTI_Line15;
//  	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;	
//  	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
//  	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
//  	EXTI_Init(&EXTI_InitStructure);	  	//����EXTI_InitStruct��ָ���Ĳ�����ʼ������EXTI�Ĵ���

////    //GPIOA.0	  �ж����Լ��жϳ�ʼ������
////  	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA,GPIO_PinSource0);

////   	EXTI_InitStructure.EXTI_Line=EXTI_Line0;
////  	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;	
////  	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
////  	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
////  	EXTI_Init(&EXTI_InitStructure);		//����EXTI_InitStruct��ָ���Ĳ�����ʼ������EXTI�Ĵ���


// 
//  	NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn;			//ʹ�ܰ������ڵ��ⲿ�ж�ͨ��
//  	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x02;	//��ռ���ȼ�2 
//  	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x02;					//�����ȼ�1
//  	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;								//ʹ���ⲿ�ж�ͨ��
//  	NVIC_Init(&NVIC_InitStructure);  	  //����NVIC_InitStruct��ָ���Ĳ�����ʼ������NVIC�Ĵ���
//		
//		NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;			//ʹ�ܰ������ڵ��ⲿ�ж�ͨ��
//  	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x02;	//��ռ���ȼ�2�� 
//  	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x01;					//�����ȼ�1
//  	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;								//ʹ���ⲿ�ж�ͨ��
//  	NVIC_Init(&NVIC_InitStructure); 
// 
// 
//   	NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;			//ʹ�ܰ������ڵ��ⲿ�ж�ͨ��
//  	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x02;	//��ռ���ȼ�2�� 
//  	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x00;					//�����ȼ�1
//  	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;								//ʹ���ⲿ�ж�ͨ��
//  	NVIC_Init(&NVIC_InitStructure); 
// 
// 
//}
// 
////void EXTI0_IRQHandler(void)
////{
//////  Delay_ms(10);    //����
//////	begin_mode++;
//////	begin_mode=begin_mode%3;
////	
////	
//////	if(WK_UP==1)
//////	{	  
//////		//LED0=!LED0;
//////		//LED1=!LED1;	
//////		//printf("hello");
//////	}
////	EXTI_ClearITPendingBit(EXTI_Line1);  //���EXTI0��·����λ
////}
//// void EXTI9_5_IRQHandler(void)
////{					 
//////	if(KEY0==0)	{
//////	//	LED0=!LED0;
//////	}
////// Delay_ms(10);    //����
//////	begin_mode++;
//////	begin_mode=begin_mode%3;
//// 	 EXTI_ClearITPendingBit(EXTI_Line2);    //���LINE5�ϵ��жϱ�־λ  
////}


//void LED_Init(void)
//{
// 
// GPIO_InitTypeDef  GPIO_InitStructure;
// 	
// RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOD, ENABLE);	 //ʹ��PA,PD�˿�ʱ��
//	
// GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;				 //LED0-->PA.8 �˿�����
// GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 //�������
// GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 //IO���ٶ�Ϊ50MHz
// GPIO_Init(GPIOA, &GPIO_InitStructure);					 //�����趨������ʼ��GPIOA.8
// GPIO_SetBits(GPIOA,GPIO_Pin_8);						 //PA.8 �����

// GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;	    		 //LED1-->PD.2 �˿�����, �������
// GPIO_Init(GPIOD, &GPIO_InitStructure);	  				 //������� ��IO���ٶ�Ϊ50MHz
// GPIO_SetBits(GPIOD,GPIO_Pin_2); 						 //PD.2 ����� 
//}
// 

//void EXTI15_10_IRQHandler(void)
//{
//  Delay_ms(15);  //����	
//	if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_15)==0)
//	{
//		
//		++stop_flag;
//		EXTI_ClearITPendingBit(EXTI_Line15);  //���LINE15��·����λ
//	}
//}


// void EXTIX_IO_INIT(void) //IO��ʼ��
//{ 
// 	  GPIO_InitTypeDef GPIO_InitStructure;
// 
// 	  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);//ʹ��PORTAʱ��
//	  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_1;//A1
//	  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; //���ó���������
//	  GPIO_Init(GPIOA, &GPIO_InitStructure);//��ʼ��GPIOA
//	
//	
//	  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);//ʹ��PORTBʱ��
//	  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_4;//B4
//	  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; //���ó���������
//	  GPIO_Init(GPIOB, &GPIO_InitStructure);//��ʼ��GPIOB3
//}

 void EXTIX_IO_INIT(void) //IO��ʼ��
{ 
 	  GPIO_InitTypeDef GPIO_InitStructure;
 
//	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);//ʹ��PORTAʱ��
//	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0;//A1
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; //���ó���������
//	GPIO_Init(GPIOA, &GPIO_InitStructure);//��ʼ��GPIOA
	
	
	  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);//ʹ��PORTBʱ��
	  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_4;//B4
	  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; //���ó���������
	  GPIO_Init(GPIOB, &GPIO_InitStructure);//��ʼ��GPIOB3

}

void EXTIX_Init(void)
{
 
	  EXTI_InitTypeDef EXTI_InitStructure;
 	  NVIC_InitTypeDef NVIC_InitStructure;

//    EXTIX_IO_INIT();	 //	�����˿ڳ�ʼ��

//		RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);	//ʹ�ܸ��ù���ʱ��
//	//--------------------------------------------------------------------//
//	  GPIO_EXTILineConfig(GPIO_PortSourceGPIOA,GPIO_PinSource0); //GPIOA1 ӳ�䵽�ж���

//	  EXTI_InitStructure.EXTI_Line=EXTI_Line0;	//A1
// 	  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;	
//  	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
//  	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
//  	EXTI_Init(&EXTI_InitStructure);	 	//����EXTI_InitStruct��ָ���Ĳ�����ʼ������EXTI�Ĵ���
//	
//	
//	  NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn;			//A1��LINE1
//  	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x02;	//��ռ���ȼ�2�� 
//  	NVIC_InitStructure.NVIC_IRQChannelSubPriority= 0x02;					//�����ȼ�2
//  	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;								//ʹ���ⲿ�ж�ͨ��
//  	NVIC_Init(&NVIC_InitStructure);
//		
		
		//---------------------------------------------------------------------//
	  GPIO_EXTILineConfig(GPIO_PortSourceGPIOB,GPIO_PinSource4); //GPIOB4 ӳ�䵽�ж���

	  EXTI_InitStructure.EXTI_Line=EXTI_Line4;	//B4
 	  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;	
  	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
  	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
  	EXTI_Init(&EXTI_InitStructure);	 	//����EXTI_InitStruct��ָ���Ĳ�����ʼ������EXTI�Ĵ���
	
	
	  NVIC_InitStructure.NVIC_IRQChannel = EXTI4_IRQn;			//B3��LINE3
  	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x02;	//��ռ���ȼ�2�� 
  	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x02;					//�����ȼ�2
  	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;								//ʹ���ⲿ�ж�ͨ��
  	NVIC_Init(&NVIC_InitStructure);
		
			
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA,GPIO_PinSource15);

//  	EXTI_InitStructure.EXTI_Line=EXTI_Line15;
//  	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;	
//  	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
//  	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
//  	EXTI_Init(&EXTI_InitStructure);	  	//����EXTI_InitStruct��ָ���Ĳ�����ʼ������EXTI�Ĵ���
 
}

//�ⲿ�ж�1�������
//void EXTI1_IRQHandler(void)
//{
//	Delay_ms(10);//����
//	if(++dengdai>2)
//	{
//		dengdai=0;
//		begin_mode++;
//		begin_mode%=3;
//	}
//	EXTI_ClearITPendingBit(EXTI_Line5);  //���LINE1�ϵ��жϱ�־λ  
//}


unsigned char dengdai=0;

void EXTI4_IRQHandler(void)
{
	
	///Delay_ms(5);//����
	if(++dengdai>2)
	{
		dengdai=0;
		stop_flag++;
		stop_flag%=2;
	}
	EXTI_ClearITPendingBit(EXTI_Line4);  //���LINE3�ϵ��жϱ�־λ  
}



float huoquzhengzhibili(unsigned char now1_x,unsigned char now2_x,unsigned char now1_y,unsigned char now2_y)
{
	//n2 - n1
	  float k;
		if(now2_x<now1_x)
		{
		zhengzhi_x= now1_x-now2_x;
		}
		else
		{
		zhengzhi_x= now2_x-now1_x;
		}
		
   if(now2_y<now1_y)
		{
		zhengzhi_y= now1_y-now2_y;
		}
		else
		{
		zhengzhi_y= now2_y-now1_y;
		}
			
		k = zhengzhi_y/zhengzhi_x;
		if(k<0.25)k=0.25;
		if(k>2)k=2;
		
		return k;
}

void fengduanpid(unsigned char now1_x,unsigned char now2_x,unsigned char now1_y,unsigned char now2_y)
{
		if(huoquzhengzhibili(now1_x,now2_x,now1_y,now2_y)<=0.25) ///jie jing heng shu
		{
				read_x.KP = 0.5;
				read_x.KI = 0.1;
				read_y.KP = 0.3;
				read_y.KI = 0.1;
		}
		else if(huoquzhengzhibili(now1_x,now2_x,now1_y,now2_y)<=0.5)
		{
				read_x.KP = 0.7;
				read_x.KI = 0.12;
				read_y.KP = 0.35;
				read_y.KI = 0.1;
			//	read_y.KD = 1;	
		}
		else if(huoquzhengzhibili(now1_x,now2_x,now1_y,now2_y)<=0.75)
		{
			  read_x.KP = 0.7;
				read_x.KI = 0.1;
				read_y.KP = 0.33;
				read_y.KI = 0.1;
			//	read_y.KD = 1;
		}
		else if(huoquzhengzhibili(now1_x,now2_x,now1_y,now2_y)<=1)
		{
			  read_x.KP = 0.8;
				read_x.KI = 0.15;
				read_y.KP = 0.3;
				read_y.KI = 0.1;
		}
		else if(huoquzhengzhibili(now1_x,now2_x,now1_y,now2_y)<=1.25)
		{
			  read_x.KP = 0.8;
				read_x.KI = 0.15;
				read_y.KP = 0.32;
				read_y.KI = 0.1;
			//	read_y.KD = 1;
		}
		else if(huoquzhengzhibili(now1_x,now2_x,now1_y,now2_y)<=1.5)
		{
			 read_x.KP = 0.2;
				read_x.KI = 0.1;
				read_y.KP = 0.6;
				read_y.KI = 0.4;
			
		}
		else if(huoquzhengzhibili(now1_x,now2_x,now1_y,now2_y)<=2)
		{
			  read_x.KP = 0.2;
				read_x.KI = 0.1;
				read_y.KP = 0.6;
				read_y.KI = 0.4;
				read_y.KD = 1;
		}
		else///hen shu 
		{
				read_x.KP = 0.5;
				read_x.KI = 0.1;
				read_y.KP = 0.23;
				read_y.KI = 0.12;
				read_y.KD = 1;
		}
}




int main(void)
{
	OLED_Init();
	Servo_Init();
	KEY_Init();
	uart2_init(115200);
	PID_Init_x(&read_x);
	PID_Init_y(&read_y);
	Timer_Init();	
	//EXTIX_Init();
	//LED_Init();
	EXTIX_Init();
	
	OLED_ShowString(1,1,"begin:");
	OLED_ShowString(1,9,"go");
	OLED_ShowString(2,1,"rd_x:");//91 68       192 67          
	OLED_ShowString(2,10,"y:");
	OLED_ShowString(3,1,"n1_x:");
	OLED_ShowString(3,9,"y:");

	OLED_ShowString(4,1,"ti,");
	OLED_ShowString(4,10,"d:");
	
	
	begin(center_x,center_y); 
	Delay_ms(2000);
	
	//NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);// �����ж����ȼ�����2
	
	anjian_init();
	si_x = left_x;
	si_y = left_y;
	while (1)
	{
/////////////duo ji tiao jie chu 		
	   //dengdai tiao jie jiange   tiaojie shijian/tiaojie jiange = tiaojie ci shu    1s/100ms = 10ci
//////////////////////////
//		KeyNum=KEY_Scan(0);
//		if(KeyNum==2)
//		{
//			begin_mode++;
//			begin_mode%=2;
//		}
		
		

////////////////////////////////////////////////////////
				//begin_mode =2;//qi dong shi zhi dui dui yin mo shi tiao shi
		//////////////////////////qi dong dui yin mo shi
		
//		if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_5)==0)
//		{
//			Delay_ms(10);
//			if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_5)==0)
//			{
//				stop_flag++;
//				stop_flag%=2;
//			}
//		}	
	if(stop_flag==0)
	{
					//begin_mode=2;
					switch(begin_mode)
					{
						case 0:                        //hui gui zhongxing moshi                    
								 begin(center_x,center_y); //hongdian gui zhong xing
							 //begin(left_x,left_y);
						pidgo_flag=0;
						rx_flag=0;
						now4_x=now3_x=now2_x=now1_x=0;
						break;
						case 1:                        // hua wai kuang tu mo shi
//									OLED_ShowNum(1,6,begin_mode,3);  
//									OLED_ShowNum(1,11,rx_flag,3);
//									OLED_ShowNum(2,6,red_x,4);  // 92 138    195 137  
//									OLED_ShowNum(2,11,red_y,4);
//									OLED_ShowNum(3,6,now1_x,3);
//									OLED_ShowNum(3,11,now1_y,3);
//									OLED_ShowNum(4,6,now2_x,4);
//									OLED_ShowNum(4,11,now2_y,4);
									pidgo_flag=0;
									rx_flag=0;
									now4_x=now3_x=now2_x=now1_x=0;
									//draw(center_x,center_y,left_x,left_y);//an zhao wei zhi hua wai kuang tu
									begin(si_x,si_y); 
									switch(si_num)
									{
										case 0:
										if(si_y>1320)//zuo shang jiao de y zhi
										{
											si_y-=1;
											Delay_ms(6);
										}
										else
										{
										si_num=1;
										}
										break;
										case 1:
										if(si_x>1180)//you shang jiao de x zhi
										{
											si_x-=1;
											Delay_ms(6);
										}
										else
										{
										si_num=2;
										}
										break;
										case 2:
										if(si_y<left_y)//zuo shang jiao de y zhi
										{
											si_y+=1;
											Delay_ms(6);
										}
										else
										{
										si_num=3;
										}
										break;
										case 3:
										if(si_x<1480)//zuo shang jiao de y zhi
										{
											si_y=left_y-15;
											si_x+=1;
											Delay_ms(6);
										}
										else
										{
											si_y=left_y;
										  si_num=0;
										}
										break;									
									}
									
									OLED_ShowString(1,1,"begin:");
									OLED_ShowString(1,9,"go");
									OLED_ShowString(2,1,"rd_x:");//91 68       192 67          
									OLED_ShowString(2,10,"y:");
									OLED_ShowString(3,1,"n1_x:");
									OLED_ShowString(3,9,"y:");
									OLED_ShowString(4,1,"sx");
									OLED_ShowString(4,10,"sy");
									OLED_ShowNum(1,6,begin_mode,3); 
									OLED_ShowNum(1,11,rx_flag,3);   
									OLED_ShowNum(2,6,red_x,4);  // 92 138    195 137  
									OLED_ShowNum(2,11,red_y,4);
									OLED_ShowNum(3,6,now1_x,3);
									OLED_ShowNum(3,11,now1_y,3);
									OLED_ShowNum(4,3,si_x,4);
									OLED_ShowNum(4,12,si_y,4);

									
						break;
						case 2:                        //jin ru hei kuang hong dian zhui zhong moshi       
									if((now4_x==0)&&(now3_x==0)&&(now2_x==0)&&(now1_x==0))
									{
										 begin(center_x,center_y);
										Delay_ms(1000);
										rx_flag=1; 									
									}
									else
									{
											PWM_SetCompare3(now_x); //x a6  jiansao wang you 500 2500   jia zuo	
											PWM_SetCompare2(now_y); //y a1 zhengjia wang qian  jiushixiajiang500 2500
											Delay_ms(150);
									}//hai mei jie shou di yi ci zuo biao shu ju
							//	  pidgo_flag=1;//qi dong pid tiao jie  //yi bang qing kuan xia jie shou hou hui zi ji da kai
								//	who_is();//mo hu tiao jie deng chu zuidax,y he zuixiaox,y
									
						break;
						}
	/////////////////////////////////////////////////////////////////
			
						
						
	////////////////////////////////////////////////////////////////		
				if(pidgo_flag==1)//kaishi pid tiaojie
				{
									//mode = 1;//ying gai qu diao bu ran bu hui geng xing si ge zuo biao dian bing qie zhi pao yige dian
									switch(mode)
									{ 
										case 0:									
											go_x=now1_x;
											go_y=now1_y;	
										break;
										case 1:	
	//////////////////////yao kai qi zhe bu fen zhu si yao xian kai qi shang mian de mo hu tiao//////////////////////
											read_x.KP = 0.4;
											read_x.KI = 0.1;  
											read_y.KP = 0.23; //heng zhe shu zhe
											read_y.KI = 0.06;
											read_y.KD = 1;	

														fengduanpid(now1_x,now2_x,now1_y,now2_y);
///////////////////////////////xian qu chu zheng fu										
							
																				
											
											
											
											bilibili = duanshu/10; 
											go_x=now1_x+(now2_x-now1_x)*bilibili;
											go_y=now1_y+(now2_y-now1_y)*bilibili;
	/////////////////////////////////////////bu kai qi no hu tiao jie yong zhe bu fen////////////////////////////////////////////////////////////////
											//go_x=now2_x;
											//go_y=now2_y;	
	//////////////////////////////////////////////
										break;
										case 2:
													fengduanpid(now2_x,now3_x,now2_y,now3_y);
	//////////////////////yao kai qi zhe bu fen zhu si yao xian kai qi shang mian de mo hu tiao//////////////////////
										
								
										
										
											bilibili = duanshu/10; 
											go_x=now2_x+(now3_x-now2_x)*bilibili;
											go_y=now2_y+(now3_y-now2_y)*bilibili;
	/////////////////////////////////////////bu kai qi no hu tiao jie yong zhe bu fen////////////////////////////////////////////////////////////////
											//go_x=now3_x;
											//go_y=now3_y;
	//////////////////////////////////////////////									
										break;
										case 3:
															fengduanpid(now3_x,now4_x,now3_y,now4_y);
	//////////////////////yao kai qi zhe bu fen zhu si yao xian kai qi shang mian de mo hu tiao//////////////////////
										
											bilibili = duanshu/10; 
											go_x=now3_x+(now4_x-now3_x)*bilibili;
											go_y=now3_y+(now4_y-now3_y)*bilibili;
	/////////////////////////////////////////bu kai qi no hu tiao jie yong zhe bu fen////////////////////////////////////////////////////////////////
											//go_x=now4_x;
											//go_y=now4_y;	
	//////////////////////////////////////////////
										break;
										case 4:
															fengduanpid(now4_x,now1_x,now4_y,now1_y);
	//////////////////////yao kai qi zhe bu fen zhu si yao xian kai qi shang mian de mo hu tiao//////////////////////
											bilibili = duanshu/10; 
											go_x=now4_x+(now1_x-now4_x)*bilibili;
											go_y=now4_y+(now1_y-now4_y)*bilibili;
	/////////////////////////////////////////bu kai qi no hu tiao jie yong zhe bu fen////////////////////////////////////////////////////////////////
											//go_x=now4_x;
											//go_y=now4_y;	
	//////////////////////////////////////////////
										break;	
										
									}			
						
									next_x = red_x-go_x;
									next_y = red_y-go_y;
												
									turn_x = PID_Contrl(&read_x,next_x);
									turn_y = PID_Contrl(&read_y,next_y);
									now_x = now_x - turn_x;
									now_y = now_y + turn_y;
				}
	//////////////////////////////////////////////////////////////////
				
				
				
				

			if(now_x>=1480)now_x=1480;//xian ding fan wei  // zui zuo
			if(now_y>=1530)now_y=1530;//zui xai
			if(now_x<=1180)now_x=1180;// zui you 
			if(now_y<=1320)now_y=1320;// zui shang
	//		now_x = now_x - next_x*0.25;
	//		now_y = now_y + next_y*0.25;	
			//}
	////////////////////////////////////////////////////		
			
			
	///////////////xianshi
			OLED_ShowNum(1,6,begin_mode,3); 
//			OLED_ShowNum(1,11,rx_flag,3);   
//			OLED_ShowNum(2,6,red_x,4);  // 92 138    195 137  
//			OLED_ShowNum(2,11,red_y,4);
//			OLED_ShowNum(3,6,now1_x,3);
//			OLED_ShowNum(3,11,now1_y,3);
//			OLED_ShowNum(4,6,timer_pid,4);
//			OLED_ShowNum(4,11,duanshu,4);
	//	 //draw(1520,1290,1620,1390);
	////////////////////////////////////////////////////////
		}

	
	}
}













 





void TIM1_UP_IRQHandler(void)
{
static uint16_t key_count=0;
	if (TIM_GetITStatus(TIM1, TIM_IT_Update) == SET)
	{
	
		
		
		key_count++;
		if(key_count==1)
    {
		  key_count=0;
		  KeyNum=KEY_Scan(0);
		  if(KeyNum==2)
			{
		    begin_mode++;
				begin_mode%=3;
		  }
		  if(KeyNum==1)
			{
				
					
		  }
		}
		
		
		
		
				
		if(pidgo_flag==1)//shi fou kai shi pid tiao jie
		{
			timer_pid++;
		}
		if(timer_pid>=400)//mei ge dian de dui yin tiao jie shi jian 
		{
			mode++;
			if(mode == 5)
			{
				mode=0;
				rx_flag=1; // chong xing jie shou 4 ge dian
				pidgo_flag=0;
			}
			timer_pid=0;
		}		
		else if(timer_pid<40)
		{
			duanshu = 1;
		}
		else if((timer_pid>=40)&&(timer_pid<80))
		{
			duanshu = 2;
		}
		else if((timer_pid>=80)&&(timer_pid<120))
		{
			duanshu = 3;
		}
		else if((timer_pid>=120)&&(timer_pid<160))
		{
			duanshu = 4;
		}
		else if((timer_pid>=160)&&(timer_pid<200))
		{
			duanshu = 5;
		}
		else if((timer_pid>=200)&&(timer_pid<240))
		{
			duanshu = 6;
		}
		else if((timer_pid>=240)&&(timer_pid<280))
		{
			duanshu = 7;
		}
		else if((timer_pid>=280)&&(timer_pid<320))
		{
			duanshu = 8;
		}
		else if((timer_pid>=320)&&(timer_pid<360))
		{
			duanshu = 9;
		}
		else if((timer_pid>=360)&&(timer_pid<400))
		{
			duanshu = 10;
		}
//		else if(timer_pid<25)
//		{
//			duanshu = 1;
//		}
//		else if((timer_pid>=25)&&(timer_pid<50))
//		{
//			duanshu = 2;
//		}
//		else if((timer_pid>=50)&&(timer_pid<75))
//		{
//			duanshu = 3;
//		}
//		else if((timer_pid>=75)&&(timer_pid<100))
//		{
//			duanshu = 4;
//		}
//		else if((timer_pid>=100)&&(timer_pid<125))
//		{
//			duanshu = 5;
//		}
//		else if((timer_pid>=125)&&(timer_pid<150))
//		{
//			duanshu = 6;
//		}
//		else if((timer_pid>=150)&&(timer_pid<175))
//		{
//			duanshu = 7;
//		}
//		else if((timer_pid>=175)&&(timer_pid<200))
//		{
//			duanshu = 8;
//		}
//		else if((timer_pid>=200)&&(timer_pid<225))
//		{
//			duanshu = 9;
//		}
//		else if((timer_pid>=225)&&(timer_pid<250))
//		{
//			duanshu = 10;
//		}
//		else if((timer_pid>=250)&&(timer_pid<275))
//		{
//			duanshu = 11;
//		}
//		else if((timer_pid>=275)&&(timer_pid<300))
//		{
//			duanshu = 12;
//		}	
//		else if((timer_pid>=300)&&(timer_pid<325))
//		{
//			duanshu = 13;
//		}	
//		else if((timer_pid>=325)&&(timer_pid<350))
//		{
//			duanshu = 14;
//		}	
//		else if((timer_pid>=350)&&(timer_pid<375))
//		{
//			duanshu = 15;
//		}	
//		else if((timer_pid>=375)&&(timer_pid<400))
//		{
//			duanshu = 16;
//		}			
		
		
		
		
		
		TIM_ClearITPendingBit(TIM1, TIM_IT_Update);
	}
}















void USART2_IRQHandler(void)                	//����2�жϷ������
{
	if(USART_GetITStatus(USART2, USART_IT_RXNE) != RESET)  //�����ж�
		{
				rx_buf = USART_ReceiveData(USART2);
							switch(weishu)
							{
								case 0:
									if(rx_buf==0xf1)
									{
											weishu = 1;
									}
								break;
								case 1:
									if(rx_buf==0x01)
									{
											weishu = 2;
									}
								break;
								case 2:
										if(USART_ReceiveData(USART2)!=0x00)
										{
											red_x = rx_buf;	
											weishu = 3;
										}
										else
										{
											weishu = 0;
										}
								break;
								case 3:
										if(USART_ReceiveData(USART2)!=0x00)
										{
											red_y = rx_buf;
											weishu = 4;
										}
										else
										{
											weishu = 0;
										}					
								break;
								case 4:
									if((rx_buf==0x02)&&(rx_flag==1))//rx)fx_flag == 1  shi fou paowang dang qian huo qu de zuo biao 
									{
										weishu = 5;
									}
									else
									{
										weishu = 0;
									}
								break;
								case 5:
									if((rx_buf==0xff)&&(duqu_n>=8))
									{
										weishu = 0;
										rx_flag=0;										
										duqu_n = 0;			
										now1_x = jieshou[0];
										now1_y = jieshou[1];
										
										now2_x = jieshou[2];
										now2_y = jieshou[3];
										
										now3_x = jieshou[4];
										now3_y = jieshou[5];
										
										now4_x = jieshou[6];
										now4_y = jieshou[7];
										pidgo_flag = 1;   //huo qu wang xing zuo biao kai shi pid tiao jie
									}
									else
									{
										//if(USART_ReceiveData(USART2)!=0x00)
										//{
											jieshou[duqu_n]= USART_ReceiveData(USART2);
											duqu_n++;
										//}

									}
								break;
							}
			}
		
} 









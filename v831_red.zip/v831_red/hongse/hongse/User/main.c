#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Servo.h"
#include "Key.h"
#include "PWM.h"

unsigned int center_x=1525,center_y=1240;
unsigned int left_x=1625,left_y=1330;
unsigned int top_x=1520,top_y=1090,w,h,now_x=1525,now_y=1240,gettop_x,gettop_y;
int mode = 0;
unsigned char jieshou[6];
unsigned char jieshoujuxing[10];
unsigned char jieshou_flag=0,n;
unsigned char now1_x,now1_y,now2_x,now2_y,now3_x,now3_y,now4_x,now4_y;
unsigned char red_x,red_y;
int turn_x,turn_y; 
int go_x,go_y;


uint8_t KeyNum,begin_flag=0;
float Angle_y = 1320;//begin
float Angle_x = 1800;//begin
float px=0.0,py;    
typedef struct{
	float SetPoint;
	float LastError;		//�?'???2?
	float PrevError;		//�?�?'???2?
	float SumError;
	float KP;		
	float KI;		
	float KD;	
}PID;

PID read_x,read_y;
int next_x=0,next_y=0;

void uart2_init(u32 bound)
{
	  GPIO_InitTypeDef GPIO_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    
    /* Enable the USART2 Pins Software Remapping */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_AFIO, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2|RCC_APB2Periph_AFIO, ENABLE); 
    
    /* Configure USART2 Rx (PA.03) as input floating */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;    
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    /* Configure USART2 Tx (PA.02) as alternate function push-pull */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    /* Enable the USART2 Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);    
    
    USART_InitStructure.USART_BaudRate = bound;                
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;     
    USART_InitStructure.USART_Parity = USART_Parity_No;        
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;      
    
    USART_Init(USART2, &USART_InitStructure);
    USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
    /* Enable USART2 */
    USART_Cmd(USART2, ENABLE);
}


void PID_Init_x(PID* sptr)
{

	sptr->LastError = 0;       
	sptr->PrevError = 0;                                              
	sptr->SetPoint =  0;		
	sptr->SumError =  0;		
	sptr->KP=0.1;
	sptr->KI=0;
	sptr->KD=0;
}

void PID_Init_y(PID* sptr)
{

	sptr->LastError = 0;       
	sptr->PrevError = 0;                                              
	sptr->SetPoint =  0;		
	sptr->SumError =  0;		
	sptr->KP=0.1;
	sptr->KI=0;
	sptr->KD=0;
}

float PID_Contrl(PID* sptr,float NextPoint)
{
	float iError,dError,iIncPid;
	
	iError = sptr->SetPoint - NextPoint;	
	
	sptr->SumError+=iError;
	
	dError=sptr->LastError-sptr->PrevError;
	
	iIncPid =sptr->KP* iError;				
          + sptr->KI * sptr->SumError
    	    + sptr->KD * 	dError;

	sptr->PrevError = sptr->LastError;
	sptr->LastError = iError;	
	
//	if(iIncPid>999)
//		iIncPid=999;   
//	if(iIncPid<0)
//		iIncPid=0;  
	return iIncPid;						
}


void begin()     //???
{
//  PWM_SetCompare2(1500); //y
//	PWM_SetCompare3(2500); //x//fuwei
//	Delay_ms(1000);
////	PWM_SetCompare3(1667);
////	Delay_ms(1000);
////	PWM_SetCompare2(1390);//y
////	PWM_SetCompare3(1620);	//x
////	Delay_ms(1000);//zuoxia
////	
////	PWM_SetCompare2(1190);//y
////	PWM_SetCompare3(1620);	//x
////	Delay_ms(350);
////	PWM_SetCompare2(1190);//y
////	PWM_SetCompare3(1420);	//x
////	Delay_ms(350);
////	PWM_SetCompare2(1390);//y
////	PWM_SetCompare3(1420);	//x
////	Delay_ms(350);
////	PWM_SetCompare2(1390);//y
////	PWM_SetCompare3(1620);	//x
////	Delay_ms(350);
// draw(center_x,center_y,left_x,left_y);
}



int main(void)
{
	OLED_Init();
	Servo_Init();
	KEY_Init();
	uart2_init(115200);
	PID_Init_x(&read_x);
	PID_Init_y(&read_y);
	//begin(); 
	while (1)
	{		
	  PWM_SetCompare3(now_x); //x a6  jiansao wang you 500 2500   jia zuo	
		PWM_SetCompare2(now_y); //y a1 zhengjia wang qian  jiushixiajiang500 2500
		Delay_ms(250);
		KeyNum=KEY_Scan(0);
		if(KeyNum==2)
		{
			begin_flag++;
			begin_flag%=2;
		}
	 // mode = 1;
		//begin_flag=1;
		
//		if(begin_flag==1)
//		{
//			switch(mode)
//			{ 
//				case 0:	
//					go_x=now1_x;
//					go_y=now1_y;			
//				break;
//				case 1:	
//					go_x=now2_x;
//					go_y=now2_y;	
//				break;
//				case 2:	
//					go_x=now3_x;
//					go_y=now3_y;	
//				break;
//				case 3:
//					go_x=now4_x;
//					go_y=now4_y;
//				break;
//			}
//			mode++;
//			if(mode>=4)mode=0;			
			go_x=now1_x;
			go_y=now1_y;		
			next_x = red_x-go_x;
			next_y = red_y-go_y;
						
		turn_x = -PID_Contrl(&read_x,next_x);
		turn_y = -PID_Contrl(&read_y,next_y);
		now_x = now_x - turn_x;
		now_y = now_y + turn_y;
//		now_x = now_x - next_x*0.25;
//		now_y = now_y + next_y*0.25;	
		//}
		
		
		
		OLED_ShowString(1,1,"mode:");
		OLED_ShowNum(1,6,mode,1);
		OLED_ShowString(2,1,"n1_x:");
		OLED_ShowNum(2,6,now1_x,4);
		OLED_ShowString(2,10,"y:");
		OLED_ShowNum(2,11,now1_y,4);
		OLED_ShowString(3,1,"rd_x:");
		OLED_ShowNum(3,6,red_x,3);
		OLED_ShowString(3,9,"y:");
		OLED_ShowNum(3,11,red_y,3);

		OLED_ShowString(4,1,"nw_x:");
		OLED_ShowNum(4,6,now_x,4);
		OLED_ShowString(4,10,"y:");
		OLED_ShowNum(4,11,now_y,4);
//	 //draw(1520,1290,1620,1390);
	}
}




void USART2_IRQHandler(void)                	//����2�жϷ������
{
	if(USART_GetITStatus(USART2, USART_IT_RXNE) != RESET)  //�����ж�
		{
			jieshou[0] = USART_ReceiveData(USART2);		
			switch(jieshou_flag)
			{
				case 0:
				if(jieshou[0]==0x0f)
				{
					jieshou_flag=1;
				}
				else if(jieshou[0]==0xfe)
				{
					jieshou_flag=2;
				}						
		  	break;
				case 1:
				 n++;
				 jieshou[n] = USART_ReceiveData(USART2);
				 if((jieshou[5]==0xf0)&&(n>=5))
				 {
						if((jieshou[1]>=48)&&(jieshou[1]<=110)&&(jieshou[2]>=0)&&(jieshou[2]<=50))
						{
							red_x = jieshou[1];
							red_y = jieshou[2];					
							w = jieshou[3];
							h = jieshou[4];
						
							n=0;						
						}
						jieshou_flag=0;
				//	 USART_SendData(USART2,0x11);
				 }
				 else if((jieshou[5]!=0xf0)&&(n>=5))
				 {
						n=0;
						jieshou_flag=0;
				 }
				break;
				case 2:
				 n++;
				 jieshoujuxing[n] = USART_ReceiveData(USART2);
				 if((jieshoujuxing[9]==0xff)&&(n>=9))
				 {
							 now1_x=jieshoujuxing[1];
							 now1_y=jieshoujuxing[2];
							 now2_x=jieshoujuxing[3];
							 now2_y=jieshoujuxing[4];
							 now3_x=jieshoujuxing[5];
							 now3_y=jieshoujuxing[6];
							 now4_x=jieshoujuxing[7];
							 now4_y=jieshoujuxing[8];
							 n=0;				
							 jieshou_flag=0;
						//}
				 }
				 else if((jieshoujuxing[9]!=0xff)&&(n>=9))
				 {
						n=0;
						jieshou_flag=0;
				 }
				break;
			}
			USART_SendData(USART2,jieshou_flag);
			//USART_SendData(USART2,)
    } 
} 



#ifndef __PWM_H
#define __PWM_H

void PWM_Init(void);
void PWM_SetCompare2(uint16_t Compare);
void TIM3_PWM12_Init(u16 arr,u16 psc);
void PWM_SetCompare3(uint16_t Compare);

#endif

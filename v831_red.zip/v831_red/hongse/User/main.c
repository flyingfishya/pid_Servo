#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Servo.h"
#include "Key.h"
#include "PWM.h"
#include "timer.h"

unsigned int center_x=1525,center_y=1240;
unsigned int left_x=1625,left_y=1330;
unsigned int top_x=1520,top_y=1090,w,h,now_x=1525,now_y=1240,gettop_x,gettop_y;
int mode = 0;
unsigned char jieshou[10];
unsigned char jieshoujuxing[10];
unsigned char jieshou_flag=0,n;
unsigned char now1_x,now1_y,now2_x,now2_y,now3_x,now3_y,now4_x,now4_y,now5_x,now5_y,now6_x,now6_y,now7_x,now7_y,now8_x,now8_y;
unsigned char red_x,red_y;
int turn_x,turn_y; 
int go_x,go_y;
unsigned int weishu=0,duqu_n=0;
unsigned char rx_buf,zuobiaoshu,rx_flag=1,dianshu=0;
unsigned char jiehshousuoyou[100],zongci=0;
unsigned char chazhi_x=0,chazhi_y=0;
unsigned char zuida_x,zuida_y,zuixiao_x,zuixiao_y;
unsigned int timer_pid= 0,pidgo_flag=0;

uint8_t KeyNum,begin_flag=0;
float Angle_y = 1320;//begin
float Angle_x = 1800;//begin
float px=0.0,py;    
typedef struct{
	float SetPoint;
	float LastError;		//�?'???2?
	float PrevError;		//�?�?'???2?
	float SumError;
	float KP;		
	float KI;		
	float KD;	
}PID;

PID read_x,read_y;
int next_x=0,next_y=0;

void uart2_init(u32 bound)
{
	  GPIO_InitTypeDef GPIO_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    
    /* Enable the USART2 Pins Software Remapping */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_AFIO, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2|RCC_APB2Periph_AFIO, ENABLE); 
    
    /* Configure USART2 Rx (PA.03) as input floating */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;    
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    /* Configure USART2 Tx (PA.02) as alternate function push-pull */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    /* Enable the USART2 Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);    
    
    USART_InitStructure.USART_BaudRate = bound;                
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;     
    USART_InitStructure.USART_Parity = USART_Parity_No;        
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;      
    
    USART_Init(USART2, &USART_InitStructure);
    USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
    /* Enable USART2 */
    USART_Cmd(USART2, ENABLE);
}


void PID_Init_x(PID* sptr)
{

	sptr->LastError = 0;       
	sptr->PrevError = 0;                                              
	sptr->SetPoint =  0;		
	sptr->SumError =  0;		
	sptr->KP=0.12;
	sptr->KI=0.1;
	sptr->KD=0;
}

void PID_Init_y(PID* sptr)
{

	sptr->LastError = 0;       
	sptr->PrevError = 0;                                              
	sptr->SetPoint =  0;		
	sptr->SumError =  0;		
	sptr->KP=0.12;
	sptr->KI=0.1;
	sptr->KD=0;
}

float PID_Contrl(PID* sptr,float NextPoint)
{
	float iError,dError,iIncPid;
	
	iError = sptr->SetPoint - NextPoint;	
	
	sptr->SumError+=iError;
	
	dError=sptr->LastError-sptr->PrevError;
	
	iIncPid =sptr->KP* iError;				
          + sptr->KI * sptr->SumError
    	    + sptr->KD * 	dError;

	sptr->PrevError = sptr->LastError;
	sptr->LastError = iError;	
	
//	if(iIncPid>999)
//		iIncPid=999;   
//	if(iIncPid<0)
//		iIncPid=0;  
	return iIncPid;						
}


void begin()     //???
{
//  PWM_SetCompare2(1500); //y
//	PWM_SetCompare3(2500); //x//fuwei
//	Delay_ms(1000);
////	PWM_SetCompare3(1667);
////	Delay_ms(1000);
////	PWM_SetCompare2(1390);//y
////	PWM_SetCompare3(1620);	//x
////	Delay_ms(1000);//zuoxia
////	
////	PWM_SetCompare2(1190);//y
////	PWM_SetCompare3(1620);	//x
////	Delay_ms(350);
////	PWM_SetCompare2(1190);//y
////	PWM_SetCompare3(1420);	//x
////	Delay_ms(350);
////	PWM_SetCompare2(1390);//y
////	PWM_SetCompare3(1420);	//x
////	Delay_ms(350);
////	PWM_SetCompare2(1390);//y
////	PWM_SetCompare3(1620);	//x
////	Delay_ms(350);
// draw(center_x,center_y,left_x,left_y);
}

void who_is()
{
	if(now1_x>now2_x)
	{
		zuida_x = now1_x;
		zuixiao_x = now2_x;
	}
	else
	{
		zuida_x = now2_x;
		zuixiao_x = now1_x;
	}
	if(now3_x>zuida_x)
	{
		zuida_x=now3_x;
	}
	else if(now3_x<zuixiao_x)
	{
		zuixiao_x = now3_x;
	}
	if(now4_x>zuida_x)
	{
		zuida_x=now4_x;
	}
	else if(now4_x<zuixiao_x)
	{
		zuixiao_x = now4_x;
	}
	
	
	
	
	if(now1_y>now2_y)
	{
		zuida_y = now1_y;
		zuixiao_y = now2_y;
	}
	else
	{
		zuida_y = now2_y;
		zuixiao_y = now1_y;
	}
	if(now3_y>zuida_y)
	{
		zuida_y=now3_y;
	}
	else if(now3_y<zuixiao_y)
	{
		zuixiao_y = now3_y;
	}
	if(now4_y>zuida_y)
	{
		zuida_y=now4_y;
	}
	else if(now4_y<zuixiao_y)
	{
		zuixiao_y = now4_y;
	}
}



int main(void)
{
	OLED_Init();
	Servo_Init();
	KEY_Init();
	uart2_init(115200);
	PID_Init_x(&read_x);
	PID_Init_y(&read_y);
	//begin(); 
	Timer_Init();
	while (1)
	{		
	  PWM_SetCompare3(now_x); //x a6  jiansao wang you 500 2500   jia zuo	
		PWM_SetCompare2(now_y); //y a1 zhengjia wang qian  jiushixiajiang500 2500
		//Delay_ms(300);
		KeyNum=KEY_Scan(0);
		if(KeyNum==2)
		{
			begin_flag++;
			begin_flag%=2;
		}
		
		
		if((dianshu==4)|(dianshu==5))
		{
			pidgo_flag=1;
//			who_is();
//			now1_x = zuixiao_x;
//			now1_y = zuixiao_y;
//			now2_x = zuida_x;
//			now2_y = zuixiao_y;
//			now3_x = zuida_y;
//			now3_y = zuida_y;
//			now4_x = zuixiao_x;
//			now4_y = zuida_y;
		}
		else
		{
		  rx_flag=1;	
			mode=0;
		}
		
if(pidgo_flag==1)
{
			switch(mode)
			{ 
				case 0:	

				
				break;
				case 1:	
					go_x=now1_x;
					go_y=now1_y;	
				break;
				case 2:	
					go_x=now2_x;
					go_y=now2_y;	
				break;
				case 3:
					go_x=now3_x;
					go_y=now3_y;
				break;
				case 4:
					go_x=now4_x;
					go_y=now4_y;
				break;
				case 5:
					go_x=now5_x;
					go_y=now5_y;
				break;
				case 6:
					go_x=now6_x;
					go_y=now6_y;
				break;
				case 7:
					go_x=now7_x;
					go_y=now7_y;
				break;
				case 8:
					go_x=now8_x;
					go_y=now8_y;
				break;
			}			
		//   mode=0;
//			chazhi_x = red_x-go_x;
//			if(chazhi_x<0)chazhi_x=-1*chazhi_x;
//			chazhi_y = red_y-go_y;
//			if(chazhi_y<0)chazhi_y=-1*chazhi_y;
			//if( (chazhi_x<=7) && (chazhi_y<=7)  )
			//{
			//	mode++;
			
//			//}
//			if(mode>=)
//			{
//				rx_flag=1;
//				mode=0;
//			}				
			//go_x=now1_x;
			//go_y=now1_y;		
			next_x = red_x-go_x;
			next_y = red_y-go_y;
						
			turn_x = PID_Contrl(&read_x,next_x);
			turn_y = PID_Contrl(&read_y,next_y);
			now_x = now_x - turn_x;
			now_y = now_y + turn_y;
}


			if(now_x>=1625)now_x=1625;
			if(now_y>=1330)now_y=1330;
			if(now_x<=1425)now_x=1425;
			if(now_y<=1130)now_y=1130;
//		now_x = now_x - next_x*0.25;
//		now_y = now_y + next_y*0.25;	
		//}
		
		
		
		OLED_ShowString(1,1,"mode:");
		OLED_ShowNum(1,6,mode,1);
		OLED_ShowString(2,1,"rd_x:");//91 68       192 67          
		OLED_ShowNum(2,6,red_x,4);  // 92 138    195 137  
		OLED_ShowString(2,10,"y:");
		OLED_ShowNum(2,11,red_y,4);
		OLED_ShowString(3,1,"n1_x:");
		OLED_ShowNum(3,6,now1_x,3);
		OLED_ShowString(3,9,"y:");
		OLED_ShowNum(3,11,now1_y,3);

		OLED_ShowString(4,1,"n2_x:");
		OLED_ShowNum(4,6,now2_x,4);
		OLED_ShowString(4,10,"y:");
		OLED_ShowNum(4,11,now2_y,4);
//	 //draw(1520,1290,1620,1390);
	}
}










void TIM1_UP_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM1, TIM_IT_Update) == SET)
	{
	  timer_pid++;
		if(timer_pid>=120)
		{
			mode++;
			timer_pid=0;
		}
		if(mode>dianshu)
		{
			mode=0;
			rx_flag=1;
			pidgo_flag=0;
		}
		TIM_ClearITPendingBit(TIM1, TIM_IT_Update);
	}
}
















void USART2_IRQHandler(void)                	//����2�жϷ������
{
	if(USART_GetITStatus(USART2, USART_IT_RXNE) != RESET)  //�����ж�
		{
				rx_buf = USART_ReceiveData(USART2);
				if(rx_flag==1)
				{
							switch(weishu)
							{
								case 0:
									if(rx_buf=='r')
									{
											weishu = 1;
									}
								break;
								case 1:
									if(rx_buf==' ')
									{
											weishu = 2;
									}
								break;
								case 2:
									if(rx_buf==',')
									{
											weishu = 3;
											if(duqu_n == 3)
											{
												red_x = (jieshou[0]-0x30)*100+(jieshou[1]-0x30)*10+(jieshou[2]-0x30);
											}
											else
											{
												red_x = (jieshou[0]-0x30)*10+(jieshou[1]-0x30);
											}
											duqu_n = 0;
									}
									else
									{
											jieshou[duqu_n]= USART_ReceiveData(USART2);
											duqu_n++;
									}
								break;
								case 3:
									if(rx_buf==' ')
									{
											weishu = 4;
									}
								break;
								case 4:
									if(rx_buf==',')
									{
											weishu = 5;
											if(duqu_n == 3)
											{
												red_y = (jieshou[0]-0x30)*100+(jieshou[1]-0x30)*10+(jieshou[2]-0x30);
											}
											else
											{
												red_y = (jieshou[0]-0x30)*10+(jieshou[1]-0x30);
											}
											duqu_n = 0;
									}
									else
									{
											jieshou[duqu_n]= USART_ReceiveData(USART2);
											duqu_n++;
									}
								break;
								case 5:
									if(rx_buf==':')
									{
											weishu = 6;
									}
								break;
								case 6:
									if(rx_buf==' ')
									{
											weishu = 7;
									}
								break;
								case 7:
									if(rx_buf==',')//nneg dao zhebian shuo ming xiaoy 4 huozhe dayu 8
									{
											weishu = 0;
											duqu_n = 0;
									}
									else
									{
											jieshou[duqu_n]= USART_ReceiveData(USART2);
											if((jieshou[duqu_n]>=0x34)&&(jieshou[duqu_n]<=0x38))
											{
												weishu = 8;
												duqu_n = 0;
												dianshu = jieshou[duqu_n]-0x30;
											}
									}
								break;
								case 8:
									if(rx_buf==' ')
									{
											weishu = 9;
									}					
								break;
								case 9:
									if(rx_buf==',')
									{
											weishu = 10;
											if(duqu_n == 3)
											{
												now1_x = (jieshou[0]-0x30)*100+(jieshou[1]-0x30)*10+(jieshou[2]-0x30);
											}
											else
											{
												now1_x = (jieshou[0]-0x30)*10+(jieshou[1]-0x30);
											}
											duqu_n = 0;
									}
									else
									{							
											jieshou[duqu_n]= USART_ReceiveData(USART2);
											duqu_n++;		
									}
								break;
								case 10:
									if(rx_buf==' ')
									{
											weishu = 11;
									}			
								break;
								case 11:
									if(rx_buf==',')
									{
											weishu = 12;
											if(duqu_n == 3)
											{
												now1_y = (jieshou[0]-0x30)*100+(jieshou[1]-0x30)*10+(jieshou[2]-0x30);
											}
											else
											{
												now1_y = (jieshou[0]-0x30)*10+(jieshou[1]-0x30);
											}
											duqu_n = 0;
									}
									else
									{							
											jieshou[duqu_n]= USART_ReceiveData(USART2);
											duqu_n++;		
									}		
								break;
								case 12:
									if(rx_buf==' ')
									{
											weishu = 13;
									}			
								break;
								case 13:
									if(rx_buf==',')
									{
											weishu = 14;
											if(duqu_n == 3)
											{
												now2_x = (jieshou[0]-0x30)*100+(jieshou[1]-0x30)*10+(jieshou[2]-0x30);
											}
											else
											{
												now2_x = (jieshou[0]-0x30)*10+(jieshou[1]-0x30);
											}
											duqu_n = 0;
									}
									else
									{							
											jieshou[duqu_n]= USART_ReceiveData(USART2);
											duqu_n++;		
									}		
								break;
								case 14:
									if(rx_buf==' ')
									{
											weishu = 15;
									}			
								break;
								case 15:
									if(rx_buf==',')
									{
											weishu = 16;
											if(duqu_n == 3)
											{
												now2_y = (jieshou[0]-0x30)*100+(jieshou[1]-0x30)*10+(jieshou[2]-0x30);
											}
											else
											{
												now2_y = (jieshou[0]-0x30)*10+(jieshou[1]-0x30);
											}
											duqu_n = 0;
									}
									else
									{							
											jieshou[duqu_n]= USART_ReceiveData(USART2);
											duqu_n++;		
									}		
								break;
								case 16:
									if(rx_buf==' ')
									{
											weishu = 17;
									}			
								break;
								case 17:
									if(rx_buf==',')
									{
											weishu = 18;
											if(duqu_n == 3)
											{
												now3_x = (jieshou[0]-0x30)*100+(jieshou[1]-0x30)*10+(jieshou[2]-0x30);
											}
											else
											{
												now3_x = (jieshou[0]-0x30)*10+(jieshou[1]-0x30);
											}
											duqu_n = 0;
									}
									else
									{							
											jieshou[duqu_n]= USART_ReceiveData(USART2);
											duqu_n++;		
									}		
								break;
								case 18:
									if(rx_buf==' ')
									{
											weishu = 19;
									}			
								break;
								case 19:
									if(rx_buf==',')
									{
											weishu = 20;
											if(duqu_n == 3)
											{
												now3_y = (jieshou[0]-0x30)*100+(jieshou[1]-0x30)*10+(jieshou[2]-0x30);
											}
											else
											{
												now3_y = (jieshou[0]-0x30)*10+(jieshou[1]-0x30);
											}
											duqu_n = 0;
									}
									else
									{							
											jieshou[duqu_n]= USART_ReceiveData(USART2);
											duqu_n++;		
									}		
								break;
								case 20:
									if(rx_buf==' ')
									{
											weishu = 21;
									}			
								break;
								case 21:
									if(rx_buf==',')
									{
											weishu = 22;
											if(duqu_n == 3)
											{
												now4_x = (jieshou[0]-0x30)*100+(jieshou[1]-0x30)*10+(jieshou[2]-0x30);
											}
											else
											{
												now4_x = (jieshou[0]-0x30)*10+(jieshou[1]-0x30);
											}
											duqu_n = 0;
									}
									else
									{							
											jieshou[duqu_n]= USART_ReceiveData(USART2);
											duqu_n++;		
									}		
								break;
								case 22:
									if(rx_buf==' ')
									{
											weishu = 23;
									}			
								break;
								case 23:
									if(rx_buf==',')
									{
											weishu = 24;
											if(duqu_n == 3)
											{
												now4_y = (jieshou[0]-0x30)*100+(jieshou[1]-0x30)*10+(jieshou[2]-0x30);
											}
											else
											{
												now4_y = (jieshou[0]-0x30)*10+(jieshou[1]-0x30);
											}
											duqu_n = 0;
											if(dianshu<=4)
											{
												duqu_n=0;
												weishu = 0;
												rx_flag = 0;
											}
									}
									else
									{							
											jieshou[duqu_n]= USART_ReceiveData(USART2);
											duqu_n++;		
									}		
								 break;
								case 24:
									if(rx_buf==' ')
									{
											weishu = 25;
									}			
								break;
								case 25:
									if(rx_buf==',')
									{
											weishu = 26;
											if(duqu_n == 3)
											{
												now5_x = (jieshou[0]-0x30)*100+(jieshou[1]-0x30)*10+(jieshou[2]-0x30);
											}
											else
											{
												now5_x = (jieshou[0]-0x30)*10+(jieshou[1]-0x30);
											}
											duqu_n = 0;
									}
									else
									{							
											jieshou[duqu_n]= USART_ReceiveData(USART2);
											duqu_n++;		
									}		
								 break;
									case 26:
									if(rx_buf==' ')
									{
											weishu = 27;
									}			
								break;
								case 27:
									if(rx_buf==',')
									{
											weishu = 28;
											if(duqu_n == 3)
											{
												now5_y = (jieshou[0]-0x30)*100+(jieshou[1]-0x30)*10+(jieshou[2]-0x30);
											}
											else
											{
												now5_y = (jieshou[0]-0x30)*10+(jieshou[1]-0x30);
											}
											duqu_n = 0;
											if(dianshu<=5)
											{
												duqu_n=0;
												weishu = 0;
												rx_flag = 0;
											}
									}
									else
									{							
											jieshou[duqu_n]= USART_ReceiveData(USART2);
											duqu_n++;		
									}		
								 break;
									case 28:
									if(rx_buf==' ')
									{
											weishu = 29;
									}			
								break;
								case 29:
									if(rx_buf==',')
									{
											weishu = 30;
											if(duqu_n == 3)
											{
												now6_x = (jieshou[0]-0x30)*100+(jieshou[1]-0x30)*10+(jieshou[2]-0x30);
											}
											else
											{
												now6_x = (jieshou[0]-0x30)*10+(jieshou[1]-0x30);
											}
											duqu_n = 0;
									}
									else
									{							
											jieshou[duqu_n]= USART_ReceiveData(USART2);
											duqu_n++;		
									}		
								 break;
									case 30:
									if(rx_buf==' ')
									{
											weishu = 31;
									}			
								break;
								case 31:
									if(rx_buf==',')
									{
											weishu = 32;
											if(duqu_n == 3)
											{
												now6_y = (jieshou[0]-0x30)*100+(jieshou[1]-0x30)*10+(jieshou[2]-0x30);
											}
											else
											{
												now6_y = (jieshou[0]-0x30)*10+(jieshou[1]-0x30);
											}
											duqu_n = 0;
											if(dianshu<=6)
											{
												duqu_n=0;
												weishu = 0;
												rx_flag = 0;
											}
									}
									else
									{							
											jieshou[duqu_n]= USART_ReceiveData(USART2);
											duqu_n++;		
									}		
								 break;
									case 32:
									if(rx_buf==' ')
									{
											weishu = 33;
									}			
								break;
								case 33:
									if(rx_buf==',')
									{
											weishu = 34;
											if(duqu_n == 3)
											{
												now7_x = (jieshou[0]-0x30)*100+(jieshou[1]-0x30)*10+(jieshou[2]-0x30);
											}
											else
											{
												now7_x = (jieshou[0]-0x30)*10+(jieshou[1]-0x30);
											}
											duqu_n = 0;
									}
									else
									{							
											jieshou[duqu_n]= USART_ReceiveData(USART2);
											duqu_n++;		
									}		
								 break;
									case 34:
									if(rx_buf==' ')
									{
											weishu = 35;
									}			
								break;
								case 35:
									if(rx_buf==',')
									{
											weishu = 36;
											if(duqu_n == 3)
											{
												now7_y = (jieshou[0]-0x30)*100+(jieshou[1]-0x30)*10+(jieshou[2]-0x30);
											}
											else
											{
												now7_y = (jieshou[0]-0x30)*10+(jieshou[1]-0x30);
											}
											duqu_n = 0;
											if(dianshu<=7)
											{
												duqu_n=0;
												weishu = 0;
												rx_flag = 0;
											}
									}
									else
									{							
											jieshou[duqu_n]= USART_ReceiveData(USART2);
											duqu_n++;		
									}		
								 break;
									case 36:
									if(rx_buf==' ')
									{
											weishu = 37;
									}			
								break;
								case 37:
									if(rx_buf==',')
									{
											weishu = 38;
											if(duqu_n == 3)
											{
												now8_x = (jieshou[0]-0x30)*100+(jieshou[1]-0x30)*10+(jieshou[2]-0x30);
											}
											else
											{
												now8_x = (jieshou[0]-0x30)*10+(jieshou[1]-0x30);
											}
											duqu_n = 0;
									}
									else
									{							
											jieshou[duqu_n]= USART_ReceiveData(USART2);
											duqu_n++;		
									}		
								 break;
									case 38:
									if(rx_buf==' ')
									{
											weishu = 39;
									}			
								break;
								case 39:
									if(rx_buf==',')
									{
											weishu = 40;
											if(duqu_n == 3)
											{
												now8_y = (jieshou[0]-0x30)*100+(jieshou[1]-0x30)*10+(jieshou[2]-0x30);
											}
											else
											{
												now8_y = (jieshou[0]-0x30)*10+(jieshou[1]-0x30);
											}
											duqu_n = 0;
											if(dianshu<=8)
											{
												duqu_n=0;
												weishu = 0;
												rx_flag = 0;
											}
									}
									else
									{							
											jieshou[duqu_n]= USART_ReceiveData(USART2);
											duqu_n++;		
									}		
								 break;
								
					

							}
							
							
			} 
				
			
			
			else
			{
								switch(weishu)
								{
									case 0:
										if(rx_buf=='r')
										{
												weishu = 1;
										}
									break;
									case 1:
										if(rx_buf==' ')
										{
												weishu = 2;
										}
									break;
									case 2:
										if(rx_buf==',')
										{
												weishu = 3;
												if(duqu_n == 3)
												{
													red_x = (jieshou[0]-0x30)*100+(jieshou[1]-0x30)*10+(jieshou[2]-0x30);
												}
												else
												{
													red_x = (jieshou[0]-0x30)*10+(jieshou[1]-0x30);
												}
												duqu_n = 0;
										}
										else
										{
												jieshou[duqu_n]= USART_ReceiveData(USART2);
												duqu_n++;
										}
									break;
									case 3:
										if(rx_buf==' ')
										{
												weishu = 4;
										}
									break;
									case 4:
										if(rx_buf==',')
										{
												weishu = 5;
												if(duqu_n == 3)
												{
													red_y = (jieshou[0]-0x30)*100+(jieshou[1]-0x30)*10+(jieshou[2]-0x30);
												}
												else
												{
													red_y = (jieshou[0]-0x30)*10+(jieshou[1]-0x30);
												}
												duqu_n = 0;
										}
										else
										{
												jieshou[duqu_n]= USART_ReceiveData(USART2);
												duqu_n++;
										}
									break;
									case 5:
										duqu_n=0;
										weishu = 0;
									break;
							}
			}
		}
} 








